'''
Jake Goldstein
jsg525
N18131294
CS-UY 3943 Compiler Design & Construction
Spring 2018
Prof. Boris Aronov
'''

# Free use registers
free_use = range(1000)
open_for_use = [True] * 1000


# Label
LABEL = [2]
labels = dict()
